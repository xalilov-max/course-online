from django.shortcuts import render, get_object_or_404
from .models import Course, Lesson
from .forms import CourseForm, LessonForm


def index(request):
    courses = Course.objects.all()
    return render(request, 'index.html', {'courses': courses})


def course_detail(request, course_id):
    course = get_object_or_404(Course, pk=course_id)
    lessons = course.lessons.all()
    return render(request, 'course_detail.html', {'course': course, 'lessons': lessons})


def add_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = CourseForm()
    return render(request, 'add_course.html', {'form': form})


def add_lesson(request):
    if request.method == 'POST':
        form = LessonForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = LessonForm()
    return render(request, 'add_lesson.html', {'form': form})


def search(request):
    query = request.GET.get('q')
    results = Course.objects.filter(title__icontains=query)
    return render(request, 'search_results.html', {'results': results})
